import 'package:event/pages/login.dart';
import 'package:flutter/material.dart';
void main()
{runApp(event());

}
class event extends StatelessWidget {
  const event({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: frontpage(),
    );
  }
}
